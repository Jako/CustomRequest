<?php
/**
 * @package customrequest
 */
class CustomrequestConfigs extends xPDOSimpleObject {}
?>