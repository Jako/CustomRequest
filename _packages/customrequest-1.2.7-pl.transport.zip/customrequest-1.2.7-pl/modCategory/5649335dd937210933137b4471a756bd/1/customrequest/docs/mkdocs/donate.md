## Support CustomRequest

*CustomRequest* is and always will be free and open-source, but it still requires many man-hours of development, 
bug-fixing, support in MODX forums and on GitHub between the releases.

Please support the ongoing and past development of *CustomRequest* by making a donation below.

<div style="margin-bottom: 2em">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="8ZCMBTR7T52WN">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/de_DE/i/scr/pixel.gif" width="1" height="1">
</form>
<br/>
</div>

*CustomRequest* development is sponsored by Treehillstudio – MODX Development in Münsterland.

<a href="https://treehillstudio.com"><img alt="Treehillstudio – MODX Development in Münsterland" border="0" src="../assets/img/treehillstudio_logo_color.svg" width="188" height="56"></a>
