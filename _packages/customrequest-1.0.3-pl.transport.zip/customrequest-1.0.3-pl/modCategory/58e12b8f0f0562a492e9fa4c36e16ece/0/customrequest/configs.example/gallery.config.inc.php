<?php
$settings['gallery'] = array(
    'resourceId' => 100,
    'urlParams' => array('galAlbum', 'galItem')
);
