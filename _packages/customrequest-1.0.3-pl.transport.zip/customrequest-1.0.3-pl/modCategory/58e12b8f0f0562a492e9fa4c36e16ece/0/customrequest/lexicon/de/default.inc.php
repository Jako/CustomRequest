<?php
/**
 * CustomRequest
 *
 * Copyright 2013 by Thomas Jakobi <thomas.jakobi@partout.info>
 *
 * @package customrequest
 * @subpackage lexicon
 *
 * Default German Lexicon Entries for CustomRequest
 */

$_lang['setting_customrequest.debug'] = 'Protokolliere Debug-Informationen im MODX Fehlerprotokoll';
$_lang['setting_customrequest.configsPath'] = 'Verzeichnis aus dem die Config Dateien für das CustomRequest Plugin geladen werden';
