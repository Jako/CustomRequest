<?php
$settings['produkte'] = array(
    'resourceId' => 125,
    'urlParams' => array('category_1', 'category_2', 'category_3', 'category_4', 'category_5')
);
$settings['produkt'] = array(
    'resourceId' => 124,
    'urlParams' => array('product_id')
);
