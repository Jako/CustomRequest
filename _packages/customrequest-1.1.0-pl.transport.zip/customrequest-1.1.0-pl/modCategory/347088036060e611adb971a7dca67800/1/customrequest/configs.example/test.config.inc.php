<?php
$settings['test'] = array(
    'resourceId' => 200,
    'alias' => 'completely/different/uri/',
    'urlParams' => array('parameter1', 'parameter2')
);
