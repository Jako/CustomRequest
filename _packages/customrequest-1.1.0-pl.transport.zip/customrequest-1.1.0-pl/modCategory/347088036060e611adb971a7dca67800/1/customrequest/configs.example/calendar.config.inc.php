<?php
$settings['date'] = array(
    'alias' => 'calendar/date/',
    'urlParams' => array('year', 'month', 'day', 'title')
);
$settings['calendar'] = array(
    'alias' => 'calendar/',
    'urlParams' => array('year', 'month', 'day')
);
