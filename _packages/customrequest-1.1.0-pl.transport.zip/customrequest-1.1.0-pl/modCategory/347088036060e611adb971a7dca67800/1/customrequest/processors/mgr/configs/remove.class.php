<?php
/**
 * CustomRequest
 *
 * Copyright 2014 by Thomas Jakobi <thomas.jakobi@partout.info>
 *
 * @package customrequest
 * @subpackage processor
 *
 * Remove processor for CustomRequest CMP
 */
class CustomRequestConfigsRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'CustomrequestConfigs';
    public $languageTopics = array('customrequest:default');
    public $objectType = 'customrequest.configs';
}

return 'CustomRequestConfigsRemoveProcessor';
