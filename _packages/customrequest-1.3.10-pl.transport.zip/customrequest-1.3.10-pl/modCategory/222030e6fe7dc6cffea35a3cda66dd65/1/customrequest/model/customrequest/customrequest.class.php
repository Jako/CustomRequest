<?php
/**
 * CustomRequest
 *
 * Copyright 2013-2024 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package customrequest
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class CustomRequest
 */
class CustomRequest extends \TreehillStudio\CustomRequest\CustomRequest
{
}
