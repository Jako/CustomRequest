<?php
/**
 * Setting Lexicon Entries for CustomRequest
 *
 * @package customrequest
 * @subpackage lexicon
 */
$_lang['setting_customrequest.debug'] = 'Debug';
$_lang['setting_customrequest.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
