<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# CustomRequest

Use pretty URLs everywhere

## Features

CustomRequest is an effective routing plugin for MODX Revolution to map pretty
but not found URLs to a MODX resource and set the request parameters by
separating the URI path at the URI separators or by a regular expression.

As standard option the first characters of the not found URI will be compared
with the alias value of each config entry. If found, this config entry is used.
The alias path is stripped from the not found URI and the remaining string is
used to set the request parameters.

As a second option, the alias value of a config entry could contain a valid
regular expression and the not found URI will be matched with that expression.
If matched, this config entry is used. The first subpattern part of the
expression is stripped from the found pattern and the remaining  string is used
to identify the resource where the user is forwarded to later. At least the
found pattern is removed from the not found URI and the remaining string is
used to set the request parameters.

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/CustomRequest/

## GitHub Repository

https://github.com/Jako/CustomRequest
',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.14] - 2026-11-15

### Fixed

- Fix a fatal error after sorting the configs in the grid
- Fix a fatal error with URI parameters that are not a JSON array and validate them on save
- Remove unsafe HTML from the configs grid and fix loading it with resources in removed contexts
- Don\'t set an empty request parameter if the not found URI is the alias path
- Don\'t skip the following configs if the resource of a config could not be calculated
- Add missing error messages and fix some texts in the lexicon

## [1.3.13] - 2025-11-21

### Fixed

- Fix mapping the url to request parameters in some configurations

## [1.3.12] - 2025-11-19

### Added

- Find resources with the container suffix and the MODX HTML content type suffix

### Fixed

- Fix wrong check of regular expressions 

## [1.3.11] - 2025-08-08

### Fixed

- Fix warning: Undefined array key 1

## [1.3.10] - 2024-06-11

### Fixed

- Fix warning: Undefined array key "q"

## [1.3.9] - 2023-10-13

### Fixed

- Use the right setlocale property to get the current locale

## [1.3.8] - 2022-12-07

### Added

- Use the alias from the resource uri field and fallback to makeUrl

### Fixed

- Remove superfluous beforeSubmit code

## [1.3.7] - 2022-12-06

### Added

- Duplicate configuration by button or context menu

## [1.3.6] - 2022-11-30

### Fixed

- Fix search in the resource combo of a configuration

## [1.3.5] - 2022-01-11

### Added

- Help button

## [1.3.4] - 2022-01-10

### Changed

- Code refactoring
- Full MODX 3 compatibility

## [1.3.3] - 2021-01-19

### Changed

- Fix a not used configuration cache

## [1.3.2] - 2019-03-20

### Added

- Edit CustomRequest system settings in the custom manager page

### Changed

- Use $_REQUEST variable instead of $_SERVER variable to avoid subfolder installation issues
- Retrieve $requestUri only during OnPageNotFound

## [1.3.1] - 2018-11-13

### Added

- Log found configuration and the set request parameters

### Changed

- Cache valid configurations, even if one configuration is invalid
- Change the log level of debug messages

## [1.3.0] - 2018-07-06

### Added

- Equal aliases in different contexts are now possible
- Switch the context to the requested resource context
- Change the default engine to InnoDB

### Changed

- Calculate the alias on base of the resource context

## [1.2.7] - 2017-09-28

### Changed

- Regard the order of the configs

## [1.2.6] - 2016-06-13

### Added

- Automatic urldecode of the remaining URL parameter part

## [1.2.5] - 2016-05-19

### Changed

- Bugfix: Save configurations issue

## [1.2.4] - 2016-02-04

### Changed

- Fixing a cache issue with URLs in different contexts than the current

## [1.2.3] - 2016-01-27

### Changed

- Fixing a configuration caching issue

## [1.2.2] - 2016-01-19

### Added

- Fixing a GPM table prefix issue

## [1.2.1] - 2016-01-13

### Added

- Enhanced validation rules for a configuration during create/update

## [1.2.0] - 2016-01-11

### Added

- Configurations are cached
- The alias of a configuration could contain a regular expression

## [1.1.4] - 2015-09-10

### Changed

- Fixing the RegEx evaluation

## [1.1.3] - 2015-04-18

### Changed

- Fixing the cultureKey replacement

## [1.1.2] - 2015-03-17

### Changed

- Fixing the cultureKey replacement

## [1.1.1] - 2015-03-03

### Changed

- Bugfixes

## [1.1.0] - 2015-03-03

### Added

- Custom manager page that replaces the config files
- Automatic Import for old config files

## [1.0.3] - 2015-01-29

### Added

- Build by Git-Package-Management

### Changed

- Bugfix: Existing url parameters issue

## [1.0.2] - 2014-05-27

### Added

- Detect/Log missing/not valid config files

### Changed

- Debug logging

## [1.0.1] - 2013-1-27

### Changed

- Updated documentation and examples (\'resourceId\' instead of \'id\')

## [1.0.0] - 2013-06-09

### Added

- Initial release for MODX Revolution
',
    'setup-options' => 'customrequest-1.3.14-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.2',
      'modx' => '>=2.6',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a57a03e45394dae75f3144dfeedb8a5c',
      'native_key' => 'customrequest',
      'filename' => 'modNamespace/3e498d79a8433eb7bc52d7412ec3bf25.vehicle',
      'namespace' => 'customrequest',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1bca0f25ac8453c9ab582bcf5fc75c4',
      'native_key' => 'customrequest.debug',
      'filename' => 'modSystemSetting/baad32733c65b9e3ac04f47c78b8a3dd.vehicle',
      'namespace' => 'customrequest',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '741cee1ab76bf8a240e05a23cf1e3058',
      'native_key' => NULL,
      'filename' => 'modCategory/108edfd5f35e7023b9461702154f8bce.vehicle',
      'namespace' => 'customrequest',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '284be3ba26aa5491783e7c09a01ac732',
      'native_key' => 'customrequest.menu_home',
      'filename' => 'modMenu/dfcaec10624efb6705d6cf11e169f6b1.vehicle',
      'namespace' => 'customrequest',
    ),
  ),
);