# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.14] - 2026-11-15

### Fixed

- Fix a fatal error after sorting the configs in the grid
- Fix a fatal error with URI parameters that are not a JSON array and validate them on save
- Remove unsafe HTML from the configs grid and fix loading it with resources in removed contexts
- Don't set an empty request parameter if the not found URI is the alias path
- Don't skip the following configs if the resource of a config could not be calculated
- Add missing error messages and fix some texts in the lexicon

## [1.3.13] - 2025-11-21

### Fixed

- Fix mapping the url to request parameters in some configurations

## [1.3.12] - 2025-11-19

### Added

- Find resources with the container suffix and the MODX HTML content type suffix

### Fixed

- Fix wrong check of regular expressions 

## [1.3.11] - 2025-08-08

### Fixed

- Fix warning: Undefined array key 1

## [1.3.10] - 2024-06-11

### Fixed

- Fix warning: Undefined array key "q"

## [1.3.9] - 2023-10-13

### Fixed

- Use the right setlocale property to get the current locale

## [1.3.8] - 2022-12-07

### Added

- Use the alias from the resource uri field and fallback to makeUrl

### Fixed

- Remove superfluous beforeSubmit code

## [1.3.7] - 2022-12-06

### Added

- Duplicate configuration by button or context menu

## [1.3.6] - 2022-11-30

### Fixed

- Fix search in the resource combo of a configuration

## [1.3.5] - 2022-01-11

### Added

- Help button

## [1.3.4] - 2022-01-10

### Changed

- Code refactoring
- Full MODX 3 compatibility

## [1.3.3] - 2021-01-19

### Changed

- Fix a not used configuration cache

## [1.3.2] - 2019-03-20

### Added

- Edit CustomRequest system settings in the custom manager page

### Changed

- Use $_REQUEST variable instead of $_SERVER variable to avoid subfolder installation issues
- Retrieve $requestUri only during OnPageNotFound

## [1.3.1] - 2018-11-13

### Added

- Log found configuration and the set request parameters

### Changed

- Cache valid configurations, even if one configuration is invalid
- Change the log level of debug messages

## [1.3.0] - 2018-07-06

### Added

- Equal aliases in different contexts are now possible
- Switch the context to the requested resource context
- Change the default engine to InnoDB

### Changed

- Calculate the alias on base of the resource context

## [1.2.7] - 2017-09-28

### Changed

- Regard the order of the configs

## [1.2.6] - 2016-06-13

### Added

- Automatic urldecode of the remaining URL parameter part

## [1.2.5] - 2016-05-19

### Changed

- Bugfix: Save configurations issue

## [1.2.4] - 2016-02-04

### Changed

- Fixing a cache issue with URLs in different contexts than the current

## [1.2.3] - 2016-01-27

### Changed

- Fixing a configuration caching issue

## [1.2.2] - 2016-01-19

### Added

- Fixing a GPM table prefix issue

## [1.2.1] - 2016-01-13

### Added

- Enhanced validation rules for a configuration during create/update

## [1.2.0] - 2016-01-11

### Added

- Configurations are cached
- The alias of a configuration could contain a regular expression

## [1.1.4] - 2015-09-10

### Changed

- Fixing the RegEx evaluation

## [1.1.3] - 2015-04-18

### Changed

- Fixing the cultureKey replacement

## [1.1.2] - 2015-03-17

### Changed

- Fixing the cultureKey replacement

## [1.1.1] - 2015-03-03

### Changed

- Bugfixes

## [1.1.0] - 2015-03-03

### Added

- Custom manager page that replaces the config files
- Automatic Import for old config files

## [1.0.3] - 2015-01-29

### Added

- Build by Git-Package-Management

### Changed

- Bugfix: Existing url parameters issue

## [1.0.2] - 2014-05-27

### Added

- Detect/Log missing/not valid config files

### Changed

- Debug logging

## [1.0.1] - 2013-1-27

### Changed

- Updated documentation and examples ('resourceId' instead of 'id')

## [1.0.0] - 2013-06-09

### Added

- Initial release for MODX Revolution
