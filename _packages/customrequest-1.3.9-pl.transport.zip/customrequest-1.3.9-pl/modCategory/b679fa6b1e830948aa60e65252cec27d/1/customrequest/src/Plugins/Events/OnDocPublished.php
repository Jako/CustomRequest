<?php
/**
 * @package customrequest
 * @subpackage plugin
 */

namespace TreehillStudio\CustomRequest\Plugins\Events;

class OnDocPublished extends OnSiteRefresh
{
}
