<?php
/**
 * @package customrequest
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/customrequestconfigs.class.php');
class CustomrequestConfigs_mysql extends CustomrequestConfigs {}
?>